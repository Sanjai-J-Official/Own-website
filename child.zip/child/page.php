<?php
// Template Name: Hello World Page
get_header(); // Include the header.php file
?>
 
 
<?php
get_footer(); // Include the footer.php file
?>
