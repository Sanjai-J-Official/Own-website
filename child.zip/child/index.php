<?php
// Silence is golden.

// Template Name: Hello World Page
get_header(); // Include the header.php file
?>

 
    
   <body>
    <!-- About Me Section -->
    <section id="about" class="about">
        <h2>About Me</h2>
        <p>I am a hardworking and motivated Artificial Intelligence engineering student with a strong interest and knowledge in my field. My goal is to become a leading technologist in the AI industry. I am passionate about coding, solving problems, and developing AI-driven solutions to societal problems.</p>
    </section>

    <!-- Skills Section -->
    <section id="skills" class="skills">
        <h2>Skills</h2>
        <div class="skill-grid">
            <div class="skill-card">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/design.png" alt="UI/UX">
                <h3>UI/UX Design</h3>
                <p>Proficient in design tools like Figma, Miro & Penpot.</p>
            </div>
            <div class="skill-card">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/python.png"  alt="Python">
                <h3>Python Programming</h3>
                <p>Expert in Python, with experience in frameworks like Django.</p>
            </div>
            <div class="skill-card">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/machine-learning.png" alt="Machine Learning">
                <h3>Machine Learning</h3>
                <p>Proficient in machine learning libraries (Pandas, NumPy, Scikit-learn).</p>
            </div>
        </div>
    </section>
    <div class="process"><h1>In the process of coding, will update with more details shortly</h1></div>

    <!-- Projects Section -->
    <section id="projects" class="projects">
        <h2>Projects</h2>
        <div class="project-grid">
            <div class="project-card">
                <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/project-manager.png" alt="Project 1">
                <h3>Student Attendance Management</h3>
                <p>A Django and MySQL-based system for efficient attendance management.</p>
                <a href="https://github.com/think-big-do-hard/Student-Database">View Project</a>
            </div>
            <div class="project-card">
                <img src="<?php echo get_stylesheet_directory_uri();?>/images/recognization.png" alt="Project 2">
                <h3>AI Age Detection</h3>
                <p>A deep learning project with OpenCV, achieving 70-80% accuracy.</p>
                <a href="https://github.com/think-big-do-hard/Age-recognization">View Project</a>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="contact">
        <h2>Contact Me</h2>
        <p class="info">Phone: <a href="tel:+916383068552">+91 63830 68552</a></p>
        <p class="info">Email: <a href="mailto:sanjaijofficial@gmail.com">sanjaijofficial@gmail.com</a></p>
        <p class="info">LinkedIn: <a href="https://www.linkedin.com/in/sanjai-j-07b0b0241/">LinkedIn Profile</a></p>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Sanjai J | AI Engineer</p>
    </footer>

</body>



<?php
get_footer(); // Include the footer.php file
?>